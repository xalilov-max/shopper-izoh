from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.contrib import messages
from .models import Product, Review
from .forms import ProductReviewForm

def index(request):
    query = request.GET.get('q')  
    if query:
        products = Product.objects.filter(name__icontains=query)
    else:
        products = Product.objects.all()
    

    paginator = Paginator(products, 10)  # 10 ta mahsulot
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'product/index.html', {'page_obj': page_obj, 'query': query})

def product_detail(request, id):
    product = get_object_or_404(Product, id=id)
    related_products = Product.objects.filter(category=product.category).exclude(id=id)[:4]  
    reviews = product.reviews.all()  

    if request.method == "POST":
        form = ProductReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.product = product
            review.user = request.user
            review.save()
            messages.success(request, "Izoh qoshildi!")  
            return redirect('product_detail', id=product.id)
    else:
        form = ProductReviewForm()

    return render(request, 'product/product_detail.html', {
        'product': product,
        'related_products': related_products,
        'reviews': reviews,
        'form': form,
    })

